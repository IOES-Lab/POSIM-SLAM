"""Acoustic intensity-only planar correspondence core. No ground truth or file I/O.

OpenCV 4.10 reference implementation; planar estimates do not resolve elevation.
"""
from .acoustic_backend import cv as cv2
from .sonar_input import validate_frame,log_image_values
import numpy as np

FILTERS = ('raw', 'smooth', 'contrast', 'whiten', 'range_whiten')


def image(frame, variant):
    if variant=='echo_boundary':
        from .sonar_edges import echo_tracking_image
        return echo_tracking_image(frame)[0]
    power,support = log_image_values(frame['intensity_db'],dtype=np.float32)
    if variant == 'raw':
        # Zero acoustic power maps directly to black before filtering. Do not
        # substitute a finite log value into the raw-to-image conversion.
        raw=np.asarray(frame['intensity_db'],dtype=np.float32)
        result=cv2.GaussianBlur(np.uint8(np.clip((raw - 20) * 255 / 70, 0, 255)), (5, 5), 0)
        result[~support]=0
        return result
    power = cv2.GaussianBlur(power, (0, 0), sigmaX=1, sigmaY=2.5)
    if variant == 'contrast':
        power = (power - cv2.GaussianBlur(power, (0, 0), sigmaX=8, sigmaY=8) + 8) * 10
    elif variant == 'range_whiten':
        # Remove same-range broad returns using acoustic intensity alone.
        # This is an experimental common-mode filter, not a seabed label.
        power = (power - np.median(power, axis=1)[:, None] + 10) * 8
    elif variant == 'whiten':
        power = (power - np.median(power, axis=0)[None, :] + 15) * 5
    else:
        power = (power - 20) * 255 / 70
    result=np.uint8(np.clip(power, 0, 255));result[~support]=0
    return result


def polar_observations(pixels, frame):
    pixels = pixels.reshape(-1, 2)
    height, width = frame['intensity_db'].shape
    if not np.isfinite(pixels).all() or np.any(pixels < 0) or np.any(pixels >= [width - 1, height - 1]):
        raise ValueError('acoustic_track_outside_image')
    ranges = np.interp(pixels[:, 1], np.arange(height), frame['ranges'])
    angles = np.interp(pixels[:, 0], np.arange(width),
                       np.arctan2(frame['beam_directions'][:, 1], frame['beam_directions'][:, 0]))
    return np.column_stack((ranges, angles))


def fan_points(pixels, frame):
    polar=polar_observations(pixels,frame)
    return np.column_stack((polar[:,0]*np.cos(polar[:,1]),polar[:,0]*np.sin(polar[:,1])))


def fit(source, target):
    a, b = source.mean(0), target.mean(0)
    u, _, vt = np.linalg.svd((source - a).T @ (target - b))
    rotation = vt.T @ u.T
    if np.linalg.det(rotation) < 0:
        vt[-1] *= -1
        rotation = vt.T @ u.T
    return rotation, b - rotation @ a


def corner_pixels(frame,variant='raw',*,mask=None):
    support=np.isfinite(frame['intensity_db'])
    if mask is not None:
        mask=np.asarray(mask)
        if mask.shape!=support.shape or mask.dtype!=bool:raise ValueError('invalid_acoustic_seed_mask')
        support&=mask
    return _corner_pixels(image(frame,variant),frame['ranges'],mask=support)


def return_support(frame,pixels):
    """A candidate's nearest native bin must contain a measured finite echo."""
    points=np.asarray(pixels).reshape(-1,2)
    height,width=frame['intensity_db'].shape
    inside=(np.isfinite(points).all(axis=1)&(points>=0).all(axis=1)&(points<[width-1,height-1]).all(axis=1))
    result=np.zeros(len(points),dtype=bool)
    indices=np.rint(points[inside]).astype(int)
    result[inside]=np.isfinite(frame['intensity_db'][indices[:,1],indices[:,0]])
    return result


def _corner_pixels(a,ranges,*,mask=None):
    allowed=np.uint8(ranges[:,None]>.4)*np.ones_like(a)
    if mask is not None:
        mask=np.asarray(mask)
        if mask.shape!=a.shape or mask.dtype!=bool:raise ValueError('invalid_acoustic_seed_mask')
        allowed*=mask
    pixels=cv2.goodFeaturesToTrack(a,300,.04,5,mask=allowed,blockSize=7)
    return np.empty((0,2),dtype=np.float32) if pixels is None else pixels.reshape(-1,2)


def correspondences(previous, current, variant='raw', *, seed_pixels=None):
    """Return bounded two-frame intensity tracks before any planar fit.

    Range/azimuth observations retain unresolved elevation. A forward/backward
    pixel test is only an association candidate gate, not calibrated covariance
    or proof of a persistent physical scatterer. Indices belong to this pair;
    they are not persistent landmark IDs across subsequent calls.
    """
    validate_frame(previous);validate_frame(current)
    stamps=[int(f['stamp'][0])*1_000_000_000+int(f['stamp'][1]) for f in (previous,current)]
    if stamps[1]<=stamps[0]:raise ValueError('nonincreasing_acoustic_pair')
    if (not np.array_equal(previous['ranges'],current['ranges']) or
            not np.array_equal(previous['beam_directions'],current['beam_directions'])):
        raise ValueError('acoustic_pair_calibration_changed')
    result=dict(previous_stamp_ns=stamps[0],current_stamp_ns=stamps[1],corners=0,matched=0,
                previous_pixels=[],current_pixels=[],previous_range_azimuth=[],current_range_azimuth=[],
                forward_backward_error_pixels=[],previous_indices=[])
    a, b = image(previous, variant), image(current, variant)
    seeds=_corner_pixels(a,previous['ranges'],mask=np.isfinite(previous['intensity_db'])) if seed_pixels is None else np.asarray(seed_pixels,dtype=np.float32)
    if seeds.ndim!=2 or seeds.shape[1]!=2 or len(seeds)>300:
        raise ValueError('invalid_acoustic_seeds')
    if seed_pixels is not None:polar_observations(seeds,previous)
    if not len(seeds):
        return dict(result,reason='no_acoustic_corners')
    pixels=np.ascontiguousarray(seeds.reshape(-1,1,2))
    result['corners']=len(pixels)
    moved, forward, _ = cv2.calcOpticalFlowPyrLK(a, b, pixels, None, winSize=(21, 21), maxLevel=2)
    if moved is None or forward is None:
        return dict(result,reason='optical_flow_unavailable')
    back, backward, _ = cv2.calcOpticalFlowPyrLK(b, a, moved, None, winSize=(21, 21), maxLevel=2)
    if back is None or backward is None:
        return dict(result,reason='reverse_flow_unavailable')
    height, width = a.shape
    inside = lambda p: (np.isfinite(p).all(axis=(1, 2)) & (p >= 0).all(axis=(1, 2))
                        & (p < [width - 1, height - 1]).all(axis=(1, 2)))
    good = (forward.ravel().astype(bool) & backward.ravel().astype(bool)
            & inside(pixels) & inside(moved) & inside(back)
            & return_support(previous,pixels) & return_support(current,moved)
            & (np.linalg.norm(back - pixels, axis=2).ravel() < .5))
    return dict(result,matched=int(good.sum()),previous_indices=np.flatnonzero(good).tolist(),
        previous_pixels=pixels[good].reshape(-1,2).tolist(),current_pixels=moved[good].reshape(-1,2).tolist(),
        previous_range_azimuth=polar_observations(pixels[good],previous).tolist(),
        current_range_azimuth=polar_observations(moved[good],current).tolist(),
        forward_backward_error_pixels=np.linalg.norm(back-pixels,axis=2).ravel()[good].tolist())


def estimate(previous, current, variant, *, include_correspondences=False):
    """Fit current-to-previous planar motion using acoustic frames alone."""
    tracks=correspondences(previous,current,variant)
    result=dict(fitted=False,corners=tracks['corners'],matched=tracks['matched'])
    if include_correspondences:result['correspondences']=tracks
    if tracks.get('reason'):return dict(result,reason=tracks['reason'])
    target=fan_points(np.asarray(tracks['previous_pixels']),previous)
    source=fan_points(np.asarray(tracks['current_pixels']),current)
    if len(source) < 10:
        return dict(result, reason='insufficient_acoustic_tracks')
    rng, best = np.random.default_rng(0), np.zeros(len(source), dtype=bool)
    for _ in range(300):
        ids = rng.choice(len(source), 2, replace=False)
        if np.linalg.norm(source[ids[0]] - source[ids[1]]) < .5:
            continue
        rotation, translation = fit(source[ids], target[ids])
        inliers = np.linalg.norm(source @ rotation.T + translation - target, axis=1) < .04
        if inliers.sum() > best.sum():
            best = inliers
    result['inliers'] = int(best.sum())
    if best.sum() < 5:
        return dict(result, reason='insufficient_acoustic_consensus')
    rotation, translation = fit(source[best], target[best])
    residual = np.linalg.norm(source[best] @ rotation.T + translation - target[best], axis=1)
    return dict(result, fitted=True, translation=translation.tolist(),
                inlier_points_current_fan_m=source[best].tolist(),
                yaw_rad=float(np.arctan2(rotation[1, 0], rotation[0, 0])),
                rmse_m=float(np.sqrt(np.mean(residual ** 2))))
